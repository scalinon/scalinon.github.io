Simple example of rescaled GMM

Use of Gaussian Mixture Models (GMMs) to learn and reproduce movements represented as a combination of linear
systems with a velocity dx computed iteratively as dx = sum_i h_i (A_i x + b_i), where A_i and b_i form a matrix and vector associated with state i of the GMM. 
The novelty here is that h_i is a weight originally defined by GMM and rescaled during reproduction to allow motion commands only in the regions of the task demonstrations, while the movemement fades away outside those (according to the task constraints, that is, local variability). With the new weighting mechanism, each linear subsystem becomes independent from the others.

Usage:

Run 'demo1' in Matlab.

Reference:

Pistillo, A., Calinon, S. And Caldwell, D.G. (2011) "Bilateral Physical Interaction with a Robot Manipulator through a Weighted Combination of Flow Fields". Proc. Of the IEEE/RSJ Intl Conf. on Intelligent Robots and Systems (IROS), pp. 3047-3052.

