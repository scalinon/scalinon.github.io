HOW TO COMPILE THE PROGRAM?
###########################

Project dependency: Armadillo c++ linear algebra library (http://arma.sourceforge.net/).

This project contains three files: main.cpp, DmpGmr.h and DmpGmr.cpp. Here are the steps to compile the project with cmake:
- Change directory to /DMP-learned-by-GMR-cpp-cmdLine-v1.0
- > cmake .
- > make
- Change directory to /bin
- > ./example

If you do not have cmake, you can alternatively compile the project from the "src" folder with the following command:
 "g++ main.cpp DmpGmr.cpp -o ../bin/example -I(the path for hpp files of the armadillo library) -L(the path for the library file, '.so file') -larmadillo" .

WHAT DOES THE PROGRAM DO?
#########################

This program is a simple example of estimating the parameters of a DMP (dynamic movement primitives) through GMR (Gaussian mixture
regression). A DMP is composed of a virtual spring-damper system modulated by a non-linear force. The standard method to train a DMP is to
predefine a set of activations functions and estimate a set of force components through a weighted least-squares (WLS) approach. The
weighted sum of force components form a non-linear force perturbing the system, by moving it away from the point-to-point linear motion
while following a desired trajectory. GMR is used here to learn the joint distribution between the decay term s (determined by a canonical
dynamical system) and the non-linear force variable to estimate. Replacing WLS with GMR has the following advantages: It provides a
probabilistic formulation of DMP (e.g., to allow the exploitation of correlation and variation information, and to make the DMP approach
compatible with other statistical machine learning tools). It simultaneously learns the non-linear force together with the activation
functions. Namely, the Gaussian kernels do not need to be equally spaced in time (or at predefined values of the decay term 's'), and the
bandwidths (variance of the Gaussians) are automatically estimated from the data instead of being hand-tuned. It provides a more accurate
approximation of the non-linear perturbing force with local linear models of degree 1 instead of degree 0 (by exploiting the conditional
probability properties of Gaussian distributions).

After running the program, the follong tasks will be performed:

- Building a DMP model 
- Loading the demonstration data 
- Initialization of the model 
- Learning parameters using WLS 
- Generating new reproductions using WLS
- The trajectories are then saved in the folder "bin/data/Wls"

- Building a DMP model 
- Loading the demonstration data 
- Initialization of the model 
- Learning parameters using GMR 
- Generating new reproductions using GMR
- The trajectories are then saved in the folder "bin/data/Gmr"


REFERENCE
#########

Reference: Calinon, S., Li, Z., Alizadeh, T., Tsagarakis, N.G. and Caldwell, D.G. (2012) Statistical dynamical systems for skills
acquisition in humanoids. Proc. of the IEEE Intl Conf. on Humanoid Robots (Humanoids).

Authors: Tohid Alizadeh and Sylvain Calinon, 2012
http://programming-by-demonstration.org

This source code is given for free! In exchange, we would be grateful if you cite the following reference in any academic publication that
uses this code or part of it:

@inproceedings{Calinon12Hum,
	author="Calinon, S. and Li, Z. and Alizadeh, T. and Tsagarakis, N. G. and Caldwell, D. G.",
	title="Statistical dynamical systems for skills acquisition in humanoids",
	booktitle="Proc. {IEEE} Intl Conf. on Humanoid Robots ({H}umanoids)",
	year="2012",
	address="Osaka, Japan"
}
