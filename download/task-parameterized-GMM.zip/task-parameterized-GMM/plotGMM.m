function plotGMM(Mu, Sigma, color, display_mode, valAlpha);
%
% This function plots a representation of the components (means and 
% covariance amtrices) of a Gaussian Mixture Model (GMM) or a
% Gaussian Mixture Regression (GMR).
%
% Inputs -----------------------------------------------------------------
%   o Mu:           D x K array representing the centers of the K GMM components.
%   o Sigma:        D x D x K array representing the covariance matrices of the 
%                   K GMM components.
%   o color:        Color used for the representation
%   o display_mode: Display mode (1 is used for a GMM, 2 is used for a GMR
%                   with a 2D representation and 3 is used for a GMR with a
%                   1D representation).
%
% Author:	Sylvain Calinon, 2013
%         http://programming-by-demonstration.org/SylvainCalinon

nbData = size(Mu,2);
lightcolor = min(color+0.3,1);
nbDrawingSeg = 35;

if display_mode==1  
  t = linspace(-pi, pi, nbDrawingSeg)';
  for j=1:nbData
    %stdev = sqrtm(5.0.*Sigma(:,:,j));
    stdev = sqrtm(1.0.*Sigma(:,:,j));
    X = [cos(t) sin(t)] * real(stdev) + repmat(Mu(:,j)',nbDrawingSeg,1);
    patch(X(:,1), X(:,2), lightcolor, 'lineWidth', 1, 'EdgeColor', color);
    %plot(X(:,1), X(:,2),'-', 'color', color);
    plot(Mu(1,:), Mu(2,:), 'x', 'lineWidth', 2, 'markersize', 6, 'color', color);
  end
elseif display_mode==2
  t = linspace(-pi, pi, nbDrawingSeg)';
  for j=1:nbData
    stdev = sqrtm(1.0.*Sigma(:,:,j));
    X = [cos(t) sin(t)] * real(stdev) + repmat(Mu(:,j)',nbDrawingSeg,1);
    patch(X(:,1), X(:,2), lightcolor, 'edgecolor', color, 'facealpha',valAlpha,'edgealpha',valAlpha);
  end
  plot(Mu(1,:), Mu(2,:), '.', 'markersize', 6, 'color', color);
elseif display_mode==3
  for j=1:nbData
    ymax(j) = Mu(2,j) + sqrtm(3.*Sigma(1,1,j));
    ymin(j) = Mu(2,j) - sqrtm(3.*Sigma(1,1,j));
  end
  patch([Mu(1,1:end) Mu(1,end:-1:1)], [ymax(1:end) ymin(end:-1:1)], lightcolor, 'LineStyle', 'none');
  plot(Mu(1,:), Mu(2,:), '-', 'lineWidth', 2, 'color', color); 
elseif display_mode==4
  t = linspace(-pi, pi, nbDrawingSeg)';
  for j=1:nbData
    stdev = sqrtm(Sigma(:,:,j));
    X = [cos(t) sin(t)] * real(stdev) + repmat(Mu(:,j)',nbDrawingSeg,1);
    patch(X(:,1), X(:,2), lightcolor, 'lineWidth', 1, 'EdgeColor', color,'facealpha',valAlpha,'edgealpha',valAlpha);
    %plot(X(:,1), X(:,2),'-', 'color', color);
    plot(Mu(1,:), Mu(2,:), 'x', 'lineWidth', 1, 'color', color);
  end
elseif display_mode==5
  t = linspace(-pi, pi, nbDrawingSeg)';
  for j=1:nbData
    stdev = sqrtm(5.0.*Sigma(:,:,j));
    X = [cos(t) sin(t)] * real(stdev) + repmat(Mu(:,j)',nbDrawingSeg,1);
    patch(X(:,1), X(:,2), lightcolor, 'lineWidth', 1, 'EdgeColor', color);
    %plot(X(:,1), X(:,2),'-', 'color', color,'linewidth',1.5);
    plot(Mu(1,:), Mu(2,:), 'x', 'lineWidth', 1.5, 'color', color);
  end
end




