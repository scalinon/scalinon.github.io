TASK-PARAMETERIZED GMM V1.1

Usage:
Unzip the file and run 'demo1', 'demo2_inanimateFrames' or 'demo2_movingFrames' in Matlab.

Reference:
Calinon, S., Li, Z., Alizadeh, T., Tsagarakis, N.G. and Caldwell, D.G. (2012) Statistical dynamical systems for skills acquisition in humanoids. Proc. of the IEEE Intl Conf. on Humanoid Robots (Humanoids), pp.323-329.
  
Training of a task-parameterized Gaussian mixture model (GMM) based on candidate frames of reference.
The proposed task-parameterized GMM approach relies on the linear transformation and product properties of
Gaussian distributions to derive an expectation-maximization (EM) algorithm to train the model.
The proposed approach is contrasted with an implementation of the approach proposed by Wilson and Bobick in
1999, with an implementation applied to GMM (that we will call PGMM) and following the model described in
"Parametric Hidden Markov Models for Gesture Recognition", IEEE Trans. on Pattern Analysis and Machine
Intelligence.
In contrast to the standard PGMM approach, the new approach that we propose allows the parameterization of
both the centers and covariance matrices of the Gaussians. It has been designed for targeting problems in
which the task parameters can be represented in the form of coordinate systems, which is for example the
case in robot manipulation problems.   


Demo 1 - Simple example of task-parameterized GMM learning and comparison with standard PGMM
 
This example uses 3 trajectories demonstrated in a frame of reference that varies from one demonstration
to the other. A model of 3 Gaussian components is used to encode the data in the different frames, by providing the
parameters of the coordinate systems as inputs (transformation matrix A and offset vector b).


Demo 2 - Example of task-parameterized movement learning with DS-GMR (statistical dynamical systems based on Gaussian mixture regression) 

This demo shows how the approach can be combined with the DS-GMR model to learn movements modulated
with respect to different frames of reference. The DS-GMR model is a statistical dynamical system approach
to learn and reproduce movements with a superposition of virtual spring-damper systems
retrieved by Gaussian mixture regression (GMR). For more details, see the 'DMP-learned-by-GMR-v1.0' example
code downloadable from the website below. 


Author:	Sylvain Calinon, 2013
	http://programming-by-demonstration.org/SylvainCalinon
		
This source code is given for free! In exchange, I would be grateful if you cite
the following reference in any academic publication that uses this code or part of it:

@inproceedings{Calinon12Hum,
	author="Calinon, S. and Li, Z. and Alizadeh, T. and Tsagarakis, N. G. and Caldwell, D. G.",
	title="Statistical dynamical systems for skills acquisition in humanoids",
	booktitle="Proc. {IEEE} Intl Conf. on Humanoid Robots ({H}umanoids)",
	year="2012",
	address="Osaka, Japan",
	pages="323--329"
}
