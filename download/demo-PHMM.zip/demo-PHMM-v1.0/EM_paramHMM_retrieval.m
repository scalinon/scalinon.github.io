function [DataParam, LL, DP] = EM_paramHMM_retrieval(Data, DataParam, StatesPriors, Trans, Z, Sigma, Priors)
% Sylvain Calinon, 2010
% Linear parametric HMM, implementation inspired by: 
% Wilson and Bobick (1999), Parametric Hidden MArkov Mdoels for Gesture
% Recognition, IEEE Trans. on Pattern Analysis and Machine Intelligence

%Thresholds for the EM iterations
nbMaxSteps = 50;
nbMinSteps = 2;
maxDiffDataParam = 1E-8;

%Parameters
[nbVar, nbData] = size(Data);
nbStates = size(Sigma,3);
nbParams = length(DataParam);

for nbIter=1:nbMaxSteps
  
  %Observation probabilities
  Omega = [DataParam; 1];
  for i=1:nbStates
    MuTmp = Z(:,:,i) * Omega;
    B(i,:) = Priors(i) * gaussPDF(Data,MuTmp,Sigma(:,:,i));
  end
  %Forward variable ALPHA
  ALPHA(:,1) = StatesPriors .* B(:,1);
  %Scaling to avoid underflow issues
  c(1) = 1/sum(ALPHA(:,1)+realmin);
  ALPHA(:,1) = ALPHA(:,1) * c(1);
  for t=2:nbData
    ALPHA(:,t) = (ALPHA(:,t-1)'*Trans)' .* B(:,t); %Eq. (20) Rabiner
    %Scaling to avoid underflow issues
    c(t) = 1/sum(ALPHA(:,t)+realmin);
    ALPHA(:,t) = ALPHA(:,t) * c(t);
  end
  %ALPHA
  %Backward variable BETA
  BETA(:,nbData) = ones(nbStates,1) * c(end); %Rescaling
  for t=nbData-1:-1:1
    BETA(:,t) = Trans * (BETA(:,t+1) .* B(:,t+1)); %Eq. (25) Rabiner 
    BETA(:,t) = min(BETA(:,t)*c(t),realmax); %Rescaling
  end
  %BETA
  %Intermediate variables
  GAMMA = (ALPHA.*BETA) ./ repmat(sum(ALPHA.*BETA)+realmin,nbStates,1); %Eq. (27) Rabiner
  %GAMMA
  
  %Update DataParam
  sumTmp = zeros(nbParams,nbParams);
  DataParam = zeros(nbParams,1);
  for i=1:nbStates
    Wtmp = Z(:,1:end-1,i);
    MuTmp = Z(:,end,i);
    %MuTmp = Z(:,:,i) * Omega;
    for t=1:nbData
      sumTmp = sumTmp + (GAMMA(i,t) * Wtmp' * inv(Sigma(:,:,i)) * Wtmp);
      DataParam = DataParam + (GAMMA(i,t) * Wtmp' * inv(Sigma(:,:,i)) * (Data(:,t)-MuTmp));
    end
  end
  %sumTmp
  DataParam = pinv(sumTmp) * DataParam; %Eq. (9) Wilson and Bobick
  
  %Compute the log-likelihood through the ALPHA scaling factors
  LL(nbIter) = -sum(log(c));
  %Stop the algorithm if EM converged (small change of DataParam)
  DP(:,nbIter) = DataParam;
  if nbIter>nbMinSteps
    %norm(DP(:,nbIter)-DP(:,nbIter-1))
    if norm(DP(:,nbIter)-DP(:,nbIter-1))<maxDiffDataParam
      disp(['Retrieval: EM converged after ' num2str(nbIter) ' iterations.']); 
      return;
    end
  end
end

disp(['Retrieval: The maximum number of ' num2str(nbMaxSteps) ' EM iterations has been reached.']); 




