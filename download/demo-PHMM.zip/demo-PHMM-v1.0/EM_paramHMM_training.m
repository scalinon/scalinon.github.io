function [StatesPriors, Trans, Z, Sigma, LL] = EM_paramHMM_training(s, StatesPriors, Trans, Mu, Sigma, Priors)
% Sylvain Calinon, 2010
% Linear parametric HMM, implementation inspired by: 
% Wilson and Bobick (1999), Parametric Hidden MArkov Mdoels for Gesture
% Recognition, IEEE Trans. on Pattern Analysis and Machine Intelligence

%Thresholds for the EM iterations
nbMaxSteps = 500;
nbMinSteps = 10;
maxDiffLL = 1E-6;

%Initialization of the parameters
nbSamples = length(s);
Data=[];
for n=1:nbSamples
  Data = [Data s(n).Data];
  s(n).nbData = size(s(n).Data,2);
  s(n).Omega = [s(n).DataParam; 1];
end

[nbVar, nbData] = size(Data);
nbStates = size(Sigma,3);
nbParams = length(s(1).DataParam);

%Parametric HMM Z variables initialization
for i=1:nbStates
  %Z(:,:,i) = [eye(nbVar) Mu(:,i)]; %Eq. (5) Wilson and Bobick   
  Z(:,:,i) = [rand(nbVar,nbParams) Mu(:,i)]; %Eq. (5) Wilson and Bobick   
  %Z(:,:,i) = [zeros(nbVar,nbVar) Mu(:,i)]; %Eq. (5) Wilson and Bobick   
end

for nbIter=1:nbMaxSteps
  for n=1:nbSamples
    %Observation probabilities
    for i=1:nbStates
      MuTmp = Z(:,:,i) * s(n).Omega;
      s(n).B(i,:) = Priors(i) * gaussPDF(s(n).Data,MuTmp,Sigma(:,:,i));
    end
    %Forward variable ALPHA
    s(n).ALPHA(:,1) = StatesPriors .* s(n).B(:,1);
    %Scaling to avoid underflow issues
    s(n).c(1) = 1/sum(s(n).ALPHA(:,1)+realmin);
    s(n).ALPHA(:,1) = s(n).ALPHA(:,1) * s(n).c(1);
    for t=2:s(n).nbData
      s(n).ALPHA(:,t) = (s(n).ALPHA(:,t-1)'*Trans)' .* s(n).B(:,t); %Eq. (20) Rabiner
      %Scaling to avoid underflow issues
      s(n).c(t) = 1/sum(s(n).ALPHA(:,t)+realmin);
      s(n).ALPHA(:,t) = s(n).ALPHA(:,t) * s(n).c(t);
    end
    %Backward variable BETA
    s(n).BETA(:,s(n).nbData) = ones(nbStates,1) * s(n).c(end); %Rescaling
    for t=s(n).nbData-1:-1:1
      s(n).BETA(:,t) = Trans * (s(n).BETA(:,t+1) .* s(n).B(:,t+1)); %Eq. (25) Rabiner 
      s(n).BETA(:,t) = min(s(n).BETA(:,t)*s(n).c(t),realmax); %Rescaling
    end
    %Intermediate variables
    s(n).GAMMA = (s(n).ALPHA.*s(n).BETA) ./ repmat(sum(s(n).ALPHA.*s(n).BETA)+realmin,nbStates,1); %Eq. (27) Rabiner
    %Computation of XI (fast version)
    for i=1:nbStates
      for j=1:nbStates
        s(n).XI(i,j,:) = (s(n).ALPHA(i,1:s(n).nbData-1) .* s(n).B(j,2:s(n).nbData) .* s(n).BETA(j,2:s(n).nbData)) .* ...
          Trans(i,j)/sum(s(n).ALPHA(:,s(n).nbData)+realmin); %Eq. (37) Rabiner
      end
    end
  end
  %Concatenation of HMM intermediary variables
  GAMMA=[]; GAMMA_TRK=[]; GAMMA_INIT=[]; XI=[];
  for n=1:nbSamples
    GAMMA = [GAMMA s(n).GAMMA];
    GAMMA_INIT = [GAMMA_INIT s(n).GAMMA(:,1)];
    GAMMA_TRK = [GAMMA_TRK s(n).GAMMA(:,1:end-1)];
    XI = cat(3,XI,s(n).XI);
  end
  %Update HMM parameters
  for i=1:nbStates
    %Update Z
    Z(:,:,i) = zeros(nbVar,nbParams+1);
    sumTmp = zeros(nbParams+1,nbParams+1);
    for n=1:nbSamples
      for t=1:s(n).nbData  
        Z(:,:,i) = Z(:,:,i) + s(n).GAMMA(i,t) * s(n).Data(:,t) * s(n).Omega'; 
        sumTmp = sumTmp + s(n).GAMMA(i,t) * s(n).Omega * s(n).Omega';
      end
    end
    Z(:,:,i) = Z(:,:,i) * pinv(sumTmp); %Eq. (6) Wilson and Bobick
    %Z(:,:,i) = Z(:,:,i) * inv(sumTmp+eye(nbParams+1).*1E-4); %Eq. (6) Wilson and Bobick
    %Update the covariance matrices
    Sigma(:,:,i) = zeros(nbVar,nbVar);
    for n=1:nbSamples
      MuTmp = Z(:,:,i) * s(n).Omega;
      Data_tmp = s(n).Data - repmat(MuTmp,1,s(n).nbData);
      Sigma(:,:,i) = Sigma(:,:,i) + (Data_tmp * diag(s(n).GAMMA(i,:)) * Data_tmp') ; 
    end
    Sigma(:,:,i) = Sigma(:,:,i) / sum(GAMMA(i,:)); %Eq. (7) Wilson and Bobick   
    %Add a tiny variance to avoid numerical instability
    Sigma(:,:,i) = Sigma(:,:,i) + 1E-2.*diag(ones(nbVar,1));
  end
  StatesPriors = mean(GAMMA_INIT')'; %Eq. (40a) Rabiner
  Trans = sum(XI,3)./ repmat(sum(GAMMA_TRK,2),1,nbStates); %Eq. (40b) Rabiner  
  %Compute the average log-likelihood through the ALPHA scaling factors
  LL(nbIter)=0;
  for n=1:nbSamples
    LL(nbIter) = LL(nbIter) - sum(log(s(n).c));
  end
  LL(nbIter) = LL(nbIter)/nbSamples;
  %Stop the algorithm if EM converged (small change of LL)
  if nbIter>nbMinSteps
    if LL(nbIter)-LL(nbIter-1)<maxDiffLL
      disp(['Training: EM converged after ' num2str(nbIter) ' iterations.']); 
      return;
    end
  end
end

disp(['Training: The maximum number of ' num2str(nbMaxSteps) ' EM iterations has been reached.']); 



