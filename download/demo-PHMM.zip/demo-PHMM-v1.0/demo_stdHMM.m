function demo_stdHMM
% HMM training with own implementation of Baum-Welch EM algorithm
% Sylvain Calinon, 2010

%% Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nbStates = 4;
nbData = 100;
nbSamples = 3;
nbVar = 2;

aTmp = linspace(0,pi,nbData);
Data=[];
for n=1:nbSamples
  s(n).Data = [sin(aTmp); 2*sin(aTmp*0.5)] + (rand(nbVar,nbData)-0.5).*1E-3;
  Data = [Data s(n).Data];
end

%% Learning
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[PriorsTmp, Mu0, Sigma0] = EM_init_kmeans(Data, nbStates);
Priors0 = ones(nbStates,1);
Trans0 = mk_stochastic(rand(nbStates,nbStates));
StatesPriors0 = mk_stochastic(rand(nbStates,1));

% Trans = zeros(nbStates,nbStates);
% for i=1:nbStates-1
%   Trans(i,i) = 0.95;
%   Trans(i,i+1) = 0.05;
% end
% Trans(nbStates,nbStates) = 1.0;
% StatesPriors = zeros(nbStates,1);
% StatesPriors(1) = 1;
% Priors = ones(nbStates,1);

[StatesPriors, Trans, Mu, Sigma, LL] = EM_HMM(s, StatesPriors0, Trans0, Mu0, Sigma0, Priors0);

StatesPriors
Trans

% %Baum-Welch training without updating the GMM representation and by
% %discarding the temporal components of the GMM representation
% [LL, StatesPriors_ref, Trans_ref, Mu_ref, Sigma_ref, Priors_ref] = mhmm_em(DataHMM, ...
%  StatesPriors0, Trans0, Mu, Sigma, Priors0, 'max_iter', 100, 'verbose', 0, ...
%  'adj_mu',0,'adj_Sigma',0);
% 
% StatesPriors_ref
% Trans_ref

%% Spatial plot of the data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('position',[60,60,600,600],'name','kmeans-GMM-HMM-demo'); hold on;
plotGMM(Mu, Sigma, [0 .8 0], 1);
plot(Data(1,:), Data(2,:), '.', 'linewidth', 2, 'color', [.3 .3 .3]);
xlabel('x_1','fontsize',16); 
ylabel('x_2','fontsize',16);
axis equal;

%figure; plot(LL); xlabel('nbIter'); ylabel('LL');

pause;
close all;

