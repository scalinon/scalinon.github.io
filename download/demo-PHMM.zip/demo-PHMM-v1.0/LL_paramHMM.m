function [LL] = LL_paramHMM(Data, DataParam, StatesPriors, Trans, Z, Sigma, Priors)
% Sylvain Calinon, 2010

%Parameters
[nbVar, nbData] = size(Data);
nbStates = size(Sigma,3);
  
%Observation probabilities
Omega = [DataParam; 1];
for i=1:nbStates
  MuTmp = Z(:,:,i) * Omega;
  B(i,:) = Priors(i) * gaussPDF(Data,MuTmp,Sigma(:,:,i));
end
%Forward variable ALPHA
ALPHA(:,1) = StatesPriors .* B(:,1);
%Scaling to avoid underflow issues
c(1) = 1/sum(ALPHA(:,1));
ALPHA(:,1) = ALPHA(:,1) * c(1);
for t=2:nbData
  ALPHA(:,t) = (ALPHA(:,t-1)'*Trans)' .* B(:,t); %Eq. (20) Rabiner
  %Scaling to avoid underflow issues
  c(t) = 1/sum(ALPHA(:,t));
  ALPHA(:,t) = ALPHA(:,t) * c(t);
end

%Compute the log-likelihood through the ALPHA scaling factors
LL = -sum(log(c));




