function demo_paramHMM
% Sylvain Calinon, 2010
% Linear parametric HMM

%% Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nbStates = 4;
nbVar = 2;

needsData = 0;
needsModel = 0;
needsRepro = 0;

% aTmp = linspace(0,2*pi,nbData/2);
% s(1).Data = [sin(aTmp)+.1; cos(aTmp)];
% s(2).Data = [sin(aTmp)+.4; cos(aTmp)+.6].*1.2;
% s(1).DataParam = [.1; .1; 1];
% s(2).DataParam = [.4; .6; 1.2];

% aTmp = linspace(0,pi,nbData/4);
% s(1).Data = [[sin(aTmp)-1.1; cos(aTmp)-1.5].*0.8 [sin(aTmp)+.1; cos(aTmp)]];
% s(2).Data = [[sin(aTmp)-1.1; cos(aTmp)-1.5].*0.8 [sin(aTmp)+.4; cos(aTmp)+.6].*1.2];
% s(1).DataParam = [.1; .1];
% s(2).DataParam = [.4; .6];

%% Load data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if needsData==1
  nbData = 50;
  disp('needsData...');
  [DataTmp,nbSamples] = grabDataFromCursorDynamics(nbData);
  for n=1:nbSamples
    s(n).Data = DataTmp(1:nbVar,(n-1)*nbData+1:n*nbData);
    %s(n).DataParam = s(n).Data(:,end);
    %s(n).DataParam = [s(n).Data(:,1); s(n).Data(:,end)];
    s(n).DataParam = [mean(s(n).Data,2); max(s(n).Data(1,:))-min(s(n).Data(1,:))];
  end
  save('data/dataparamHMM05.mat','s','nbSamples');
end %needsData
load('data/dataparamHMM05.mat');

%% Learning
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Data=[];
for n=1:nbSamples
  Data=[Data s(n).Data];
end
if needsModel==1
  disp('needsModel...');

%   %Kmeans init
%   [PriorsTmp, Mu0, Sigma0] = EM_init_kmeans(Data, nbStates);
%    [PriorsTmp, Mu0, Sigma0] = EM_init_kmeans(s(1).Data, nbStates);

  %Regular timing init
  DataTiming=[];
  for n=1:nbSamples
    s(n).nbData = size(s(n).Data,2);
    DataTiming = [DataTiming [1:s(n).nbData; s(n).Data]];
  end
  [PriorsTmp, Mu0, Sigma0] = EM_init_regularTiming(DataTiming, nbStates);
  Mu0 = Mu0(2:end,:);
  Sigma0 = Sigma0(2:end,2:end,:);
  
  %HMM params init
  Priors = ones(nbStates,1);
  Trans0 = mk_stochastic(rand(nbStates,nbStates));
  StatesPriors0 = mk_stochastic(rand(nbStates,1));
  
  %HMM learning
  [StatesPriors, Trans, Z, Sigma] = EM_paramHMM_training(s, StatesPriors0, Trans0, Mu0, Sigma0, Priors);
  
  save('data/modelparamHMM05.mat','StatesPriors', 'Trans', 'Z', 'Sigma', 'Priors');
end %needsModel
load('data/modelparamHMM05.mat');

% Z
% StatesPriors
% Trans

%% Recognition and retrieval of DataParam
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if needsRepro==1
  nbData = 50;
  [DataTmp,nbRepro] = grabDataFromCursorDynamics(nbData);
  for n=1:nbRepro
    r(n).Data = DataTmp(1:nbVar,(n-1)*nbData+1:n*nbData);
  end
  for n=1:nbRepro
    [r(n).DataParam, r(n).LL, r(n).DP] = EM_paramHMM_retrieval(r(n).Data, s(1).DataParam+rand(3,1).*3, StatesPriors, Trans, Z, Sigma, Priors);
    r(n).LLmax = LL_paramHMM(s(n).Data, s(n).DataParam, StatesPriors, Trans, Z, Sigma, Priors);
    figure; hold on; plot(r(n).LL,'k-'); plot(1,r(n).LLmax,'r*'); xlabel('nbIter'); ylabel('LL');
    pause; close all;
  end
  save('data/reproparamHMM05.mat','r','nbRepro');
end %needsRepro
load('data/reproparamHMM05.mat');

%% Plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('position',[60,60,600,600],'name','kmeans-GMM-HMM-demo'); hold on;
clrmap = colormap('Jet');
xx = round(linspace(1,64,nbSamples));
clrmap = min(clrmap(xx,:),.3);
clrmap2 = min(clrmap+0.4,1);
for n=1:nbSamples
  for i=1:nbStates
    MuTmp(:,i) = Z(:,:,i) * [s(n).DataParam; 1];
  end
  plotGMM(MuTmp, Sigma, clrmap2(n,:), 1);
end
for n=1:nbSamples
  plot(s(n).Data(1,:), s(n).Data(2,:),'.','linewidth',2,'color',clrmap(n,:));
end
for n=1:nbSamples
  plot(s(n).DataParam(1), s(n).DataParam(2),'o','linewidth',2,'markersize',s(n).DataParam(3)*3,'color',clrmap(n,:));
  %plot(r(n).DP(1,:), r(n).DP(2,:),'+','linewidth',2,'markersize',10,'color',clrmap(n,:));
end
for n=1:nbRepro
  for i=1:nbStates
    MuTmp(:,i) = Z(:,:,i) * [r(n).DataParam; 1];
  end
  plotGMM(MuTmp, Sigma, [.7 .7 .7], 1);
  plot(r(n).Data(1,:), r(n).Data(2,:),'.','linewidth',2,'color',[0 0 0]);
  plot(r(n).DataParam(1), r(n).DataParam(2),'o','linewidth',2,'markersize',abs(r(n).DataParam(3))*3,'color',[0 0 0]);
end

xlabel('x_1','fontsize',16); 
ylabel('x_2','fontsize',16);
axis equal;

% pause
% plotGMM(Mu0, Sigma0, [.8 0 .8], 1);

pause;
close all;
