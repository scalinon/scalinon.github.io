function [StatesPriors, Trans, Mu, Sigma, LL] = EM_HMM(s, StatesPriors, Trans, Mu, Sigma, Priors)
% Sylvain Calinon, 2010

%Thresholds for the EM iterations
nbMaxSteps = 500;
nbMinSteps = 10;
maxDiffLL = 1E-5;

%Initialization of the parameters
nbSamples = length(s);
Data=[];
for n=1:nbSamples
  Data = [Data s(n).Data];
  s(n).nbData = size(s(n).Data,2);
end
[nbVar, nbData] = size(Data);
nbStates = size(Sigma,3);

for nbIter=1:nbMaxSteps
  for n=1:nbSamples
    %Observation probabilities
    for i=1:nbStates
      s(n).B(i,:) = Priors(i) * gaussPDF(s(n).Data,Mu(:,i),Sigma(:,:,i));
    end
    %Forward variable ALPHA
    s(n).ALPHA(:,1) = StatesPriors .* s(n).B(:,1);
    %Scaling to avoid underflow issues
    s(n).c(1) = 1/sum(s(n).ALPHA(:,1)+realmin);
    s(n).ALPHA(:,1) = s(n).ALPHA(:,1) * s(n).c(1);
    for t=2:s(n).nbData
      s(n).ALPHA(:,t) = (s(n).ALPHA(:,t-1)'*Trans)' .* s(n).B(:,t); %Eq. (20) Rabiner
      %Scaling to avoid underflow issues
      s(n).c(t) = 1/sum(s(n).ALPHA(:,t)+realmin);
      s(n).ALPHA(:,t) = s(n).ALPHA(:,t) * s(n).c(t);
    end
    %Backward variable BETA
    s(n).BETA(:,s(n).nbData) = ones(nbStates,1) * s(n).c(end); %Rescaling
    for t=s(n).nbData-1:-1:1
      s(n).BETA(:,t) = Trans * (s(n).BETA(:,t+1) .* s(n).B(:,t+1)); %Eq. (25) Rabiner
      s(n).BETA(:,t) = min(s(n).BETA(:,t)*s(n).c(t),realmax); %Rescaling
    end
    %Intermediate variables
    s(n).GAMMA = (s(n).ALPHA.*s(n).BETA) ./ repmat(sum(s(n).ALPHA.*s(n).BETA)+realmin,nbStates,1); %Eq. (27) Rabiner
    %Computation of XI (fast version)
    for i=1:nbStates
      for j=1:nbStates
        s(n).XI(i,j,:) = (s(n).ALPHA(i,1:s(n).nbData-1) .* s(n).B(j,2:s(n).nbData) .* s(n).BETA(j,2:s(n).nbData)) .* ...
          Trans(i,j)/sum(s(n).ALPHA(:,s(n).nbData)); %Eq. (37) Rabiner
      end
    end
  end
  %Concatenation of HMM intermediary variables
  GAMMA=[]; GAMMA_TRK=[]; GAMMA_INIT=[]; XI=[]; 
  for n=1:nbSamples
    GAMMA = [GAMMA s(n).GAMMA];
    GAMMA_INIT = [GAMMA_INIT s(n).GAMMA(:,1)];
    GAMMA_TRK = [GAMMA_TRK s(n).GAMMA(:,1:end-1)];
    XI = cat(3,XI,s(n).XI);
  end
  %Update HMM parameters
  for i=1:nbStates
    %Update the centers
    Mu(:,i) = Data*GAMMA(i,:)' / sum(GAMMA(i,:)); %Eq. (53) Rabiner  
    %Update the covariance matrices
    Data_tmp = Data - repmat(Mu(:,i),1,nbData);
    Sigma(:,:,i) = (Data_tmp * diag(GAMMA(i,:)) * Data_tmp') / sum(GAMMA(i,:)); %Eq. (54) Rabiner  
    %Add a tiny variance to avoid numerical instability
    Sigma(:,:,i) = Sigma(:,:,i) + 1E-5.*diag(ones(nbVar,1));
  end
  StatesPriors = mean(GAMMA_INIT')'; %Eq. (40a) Rabiner
  Trans = sum(XI,3)./ repmat(sum(GAMMA_TRK,2),1,nbStates); %Eq. (40b) Rabiner  
  %Compute the average log-likelihood through the ALPHA scaling factors
  LL(nbIter)=0;
  for n=1:nbSamples
    LL(nbIter) = LL(nbIter) - sum(log(s(n).c));
  end
  LL(nbIter) = LL(nbIter)/nbSamples;
  %Stop the algorithm if EM converged
  if nbIter>nbMinSteps
    if LL(nbIter)-LL(nbIter-1)<maxDiffLL
      disp(['EM converged after ' num2str(nbIter) ' iterations.']); 
      return;
    end
  end
end

disp(['The maximum number of ' num2str(nbMaxSteps) ' EM iterations has been reached.']); 


