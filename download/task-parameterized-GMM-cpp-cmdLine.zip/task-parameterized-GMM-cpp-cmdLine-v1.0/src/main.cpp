// Authors:	Tohid Alizadeh and Sylvain Calinon, 2012
//         	http://programming-by-demonstration.org/
#include "PGMM.h"

int main(){
  int Demo;
  cout<<"Which Demo would you like to run? (Enter 1 or 2)"<<endl;
  cin>>Demo;
  if(Demo==1){
    //Standard PGMM
    pGMM std_pgmm(2, 1, 3);                         //nbVar=2 (x,y), nbFrames=1, nbStates=3
    std_pgmm.load("../bin/data/demo1", 3, 1);       //1 refers to the data folder in ..../demo1, 3 refers to number of samples, 1 refers to Standard parameters type
    std_pgmm.init_standardPGMM();                   //Initialize a model using Standard PGMM
    std_pgmm.EMpGMMStandard();                      //Learn a model using Standard PGMM
    std_pgmm.saveModelStandard("../bin/data/demo1");//Storing the parameters of the Standard PGMM model
    //Proposed PGMM
    pGMM new_pgmm(2, 1, 3);                         //nbVar=2 (x,y), nbFrames=1, nbStates=3, mode=2 (Proposed PGMM)
    new_pgmm.load("../bin/data/demo1", 3, 1);       //1 refers to the data folder in ..../demo1, 3 refers to number of samples, 1 refers to Standard parameters type
    new_pgmm.init_proposedPGMM_kmeans();            //Initialize a model using Proposed PGMM
    new_pgmm.EMpGMMProposed();                      //Learn a model using Proposed PGMM
    new_pgmm.saveModelProposed("../bin/data/demo1");//Storing the parameters of the Proposed PGMM model
  }
  else if (Demo==2){
    pGMM pgmm(3, 2, 3);                       //nbVar=3 (t,x,y), nbFrames=2, nbStates=3,
    pgmm.load("../bin/data/demo2", 4, 2);     //2 refers to the data folder in ..../demo2, 4 refers to number of samples, 2 refers to parameters type used in the proposed PGMM
    pgmm.init_proposedPGMM_timeBased();
    pgmm.EMpGMMProposed();
    pgmm.repro("../bin/data/demo2");
    pgmm.repro_new("../bin/data/demo2");
  }
  else{
    cout<<"Demo should be 1 or 2"<<endl;
  }
  return 1;
}
