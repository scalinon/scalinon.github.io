HOW TO COMPILE THE PROGRAM?
###########################

Project dependency: Armadillo c++ linear algebra library (http://arma.sourceforge.net/).

This project contains three files: main.cpp, PGMM.h and PGMM.cpp. Here are the steps to compile the project with cmake:
- Change directory to /task-parameterized-GMM-cpp-cmdLine-v1.0
- > cmake .
- > make
- Change directory to /bin
- > ./example

If you do not have cmake, you can alternatively compile the project from the "src" folder with the following command:
 "g++ main.cpp PGMM.cpp -o ../bin/example -I(the path for hpp files of the armadillo library) -L(the path for the library file, '.so file') -larmadillo" .

To run the example, go to the 'bin' directory and run ./example. You will need to enter "1" or "2" in the Program console to select which
demo you want to execute. The following tasks will be performed as described below for each demo.

WHAT DOES THE PROGRAM DO?
#########################

Training of a task-parameterized Gaussian mixture model (GMM) based on candidate frames of reference. The proposed task-parameterized GMM
approach relies on the linear transformation and product properties of Gaussian distributions to derive an expectation-maximization (EM)
algorithm to train the model. The proposed approach is contrasted with an implementation of the approach proposed by Wilson and Bobick in
1999, with an implementation applied to GMM (that we will call PGMM) and following the model described in "Parametric Hidden Markov Models
for Gesture Recognition", IEEE Trans. on Pattern Analysis and Machine Intelligence. In contrast to the standard PGMM approach, the new
approach that we propose allows the parameterization of both the centers and covariance matrices of the Gaussians. It has been designed for
targeting problems in which the task parameters can be represented in the form of coordinate systems, which is for example the case in
robot manipulation problems.

* Demo 1: Simple example of task-parameterized GMM learning and comparison with standard PGMM:
  - Loading data
  - Learning the model using both standard PGMM and proposed PGMM
  - The parameters of the two models are saved in the folder "bin/data/demo1/" 
    (for the Standard PGMM : "ZMuStandard.txt", "SigmaStandard.txt" and "PriorsStandard.txt" 
     and for the Proposed PGMM: "ZMuProposed.txt", "ZSigmaProposed.txt" and "PriorsProposed.txt")

This example uses 3 trajectories demonstrated in a frame of reference that varies from one demonstration to the other. A model of 3
Gaussian components is used to encode the data in the different frames, by providing the parameters of the coordinate systems as inputs
(transformation matrix A and offset vector b).

* Demo 2: Example of task-parameterized movement learning with DS-GMR (statistical dynamical systems based on Gaussian mixture regression):
  - Loading data
  - Learning the model using proposed PGMM
  - Generating reproductions for the same set of parameters as in the demonstartion
  - The trajectories are then saved in the folder "bin/data/demo2" (files: data_rep_0?.txt).
  - Generating new random parameters and corresponding reproductions
  - The trajectory is then saved in the folder "bin/data/demo2/" (files: data_rep_new_0?.txt).

This demo shows how the approach can be combined with the DS-GMR model to learn movements modulated with respect to different frames of
reference. The DS-GMR model is a statistical dynamical system approach to learn and reproduce movements with a superposition of virtual
spring-damper systems retrieved by Gaussian mixture regression (GMR). For more details, see the 'DMP-learned-by-GMR-v1.0' example code
downloadable from the website below.


REFERENCE
#########

Reference: Calinon, S., Li, Z., Alizadeh, T., Tsagarakis, N.G. and Caldwell, D.G. (2012) Statistical dynamical systems for skills
acquisition in humanoids. Proc. of the IEEE Intl Conf. on Humanoid Robots (Humanoids).

Authors: Tohid Alizadeh and Sylvain Calinon, 2012
http://programming-by-demonstration.org

This source code is given for free! In exchange, we would be grateful if you cite the following reference in any academic publication that
uses this code or part of it:

@inproceedings{Calinon12Hum,
	author="Calinon, S. and Li, Z. and Alizadeh, T. and Tsagarakis, N. G. and Caldwell, D. G.",
	title="Statistical dynamical systems for skills acquisition in humanoids",
	booktitle="Proc. {IEEE} Intl Conf. on Humanoid Robots ({H}umanoids)",
	year="2012",
	address="Osaka, Japan"
}
