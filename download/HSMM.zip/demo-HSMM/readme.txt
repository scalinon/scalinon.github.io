Demo 1 - Simple example of continuous HSMM
 
Simple example of the use of Hidden Semi-Markov Model (HSMM), a form of explicit-duration Hidden Markov model, to learn and reproduce trajectories.
The movement is represented as a combination of linear systems with a velocity dx computed iteratively as dx = sum_i h_i (A_i x + b_i), where h_i is a weight defined by HSMM.
A_i and b_i form a matrix and vector associated with state i of the HSMM.

Usage:

Run 'demo1' in Matlab.

Reference:

Calinon, S., Pistillo, A. and Caldwell, D.G. (2011) Encoding the time and space constraints of a task in explicit-duration hidden Markov model. Proc. of the IEEE/RSJ Intl Conf. on Intelligent Robots and Systems (IROS).

Downloaded from:

http://programming-by-demonstration.org

