function [ALPHA, S, alpha] = hsmm_fwd_init_ts(m)
%Forward variable by using only temporal/sequential information from Trans and Pd
%Sylvain Calinon, 2014 

ALPHA = repmat(m.StatesPriors, 1, size(m.Pd,2)) .* m.Pd; %Equation (13)
S(:,1) = m.Trans' * ALPHA(:,1);	%Equation (6)
alpha = sum(ALPHA,2); %Forward variable
